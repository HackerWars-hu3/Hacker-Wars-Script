const element = {
    ip: null,
    rank: null,
    reputation: null,
    user: null,
    phpsession: null
};

sendRequest('GetPlayerInfo');

document.addEventListener("DOMContentLoaded", async function(event) {
    
    if(window.navigator.userAgent.indexOf('Chrome') > -1) 
    {
        if(location.host === "hackerwars.io")
        {                
            playerStatus();
            
            setTimeout(function() {  
                
                if(element.ip != null && element.user != null)
                {        
                    console.log('You ip: ' + element.ip);
                    
                    if (window.location.pathname == "/log" || window.location.pathname === "/internet") 
                    {                        
                        clearLogs();
                        checkLogs();

                        if(sessionStorage.getItem('backup') != null)
                        {
                            const backup_storage = sessionStorage.getItem('backup');          
                            const storageNew = JSON.parse(backup_storage); 
                            $(".logarea").before(`<textarea class="logarea" style="color:red" rows="3" name="" spellcheck="FALSE">${storageNew.join("\n")}</textarea>`);
                        }

                    } else {
                        setInterval(checkLogs, 1900);
                    }        
                } else {
                    console.log('You not logged in hacker wars');
                }
            }, 1500);
        }
    } else {
        console.log('Sorry, this extension works only in Chrome Browser');
    }
});

function clearLogs()
{
    if( ($(".logarea").length) > 0)
    {
        let textarea = $(".logarea").val();
        const find = textarea.indexOf(element.ip);

        if(find > -1)
        {
            var pattern = new RegExp("^.*" + element.ip + ".*$");
            var textFiltered = removeLinesFromText(textarea, pattern);

            $("textarea").val(textFiltered);
            $(".log").submit();
        }
    }  
};

function checkLogs() 
{
    sendXMLHttpRequest("/log", "GET", "", true, function (data) 
    {  
        const parser = new DOMParser();
        const dom = parser.parseFromString(data, "text/html");
        const html = dom.getElementsByTagName("textarea")[0];
    
        const string = html.form.innerText;
        const enemy = string.match(/^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2} - \[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\].(?!DDoSed)+.*/gmi);
          
        if( enemy != null )
        {
            const backup = string.match(/\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\]/g);
            const storage = sessionStorage.getItem('backup');
            
            if(storage.indexOf( backup[0] ) === -1)
            {
                let storage = sessionStorage.getItem('backup');
                let vazio = [];
                
                let log = JSON.parse(storage);
                let e0 = log.join("\n");
                
                vazio.push( e0 );
                vazio.push( enemy[0] );
                
                sessionStorage.setItem('backup', JSON.stringify(vazio));          
                $("#sidebar > ul:nth-child(2) > li:nth-child(5)").css("background-color", "Red");            
            }
            
        }
    
    }); 
}

function removeLinesFromText(text, pattern) {
    var lines = text.split(/[\n\r]/)
    var result = []
    for (var i = 0; i < lines.length; i++) {
        if (!pattern.test(lines[i])) result.push(lines[i])
    }
    return result.join("\n")
}

const playerStatus = async () => {
    
    $.ajax({
        type: "POST",
        url: 'ajax.php',
        dataType: "json",
        async: true,
        data: {
            func: 'getStatic'
        },
        success: function(data) 
        {
            if (data.status == 'OK') 
            {
                const json = $.parseJSON(data.msg);         
                element.ip = json[0].ip;
                element.rank = json[0].rank;
                element.reputation = json[0].reputation;
                element.user = json[0].user;
                
                if(sessionStorage.getItem('backup') === null) {
                    sessionStorage.setItem('backup', '["Second log"]');
                }
            }
        }
    });
}

function sendXMLHttpRequest(script_target, method, parameters, isAsynchronous, function_callback, sendXRequestedWithHeader = true)
{
    var xmlhttp = new XMLHttpRequest()
    var synchronousResponse = null
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var result = xmlhttp.responseText
            if (isAsynchronous) {
                function_callback(result)
            } else {
                synchronousResponse = result
            }
        }
    }
    switch (method) 
    {
        case "POST":
            xmlhttp.open("POST", script_target, isAsynchronous)
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8")
            xmlhttp.setRequestHeader("Accept", "*/*")
            if (sendXRequestedWithHeader)
                xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest")
            xmlhttp.send(parameters)
            break
        case "GET":
	    if (parameters != "" || parameters !== null){
                xmlhttp.open("GET", script_target + "?" + parameters, isAsynchronous)
	    } else{
	        xmlhttp.open("GET", script_target, isAsynchronous)
	    }
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8")
            xmlhttp.setRequestHeader("Accept", "*/*")
            if (sendXRequestedWithHeader)
                xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest")
            xmlhttp.send()
            break
        default:
            break
    }
    if (!isAsynchronous) {
        return synchronousResponse
    }
}

function sendRequest(request) {
    chrome.runtime.sendMessage({message: request}, function(response){});
};
